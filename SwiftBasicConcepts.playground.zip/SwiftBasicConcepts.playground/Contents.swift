// 1 -----------------------------------
struct Tutorial {
  var difficulty: Int = 1
}
// Structures in Swift are value types. You copy value types by value rather than reference.

var tutorial1 = Tutorial()
var tutorial2 = tutorial1
tutorial2.difficulty = 2
print(tutorial1.difficulty)
print(tutorial2.difficulty)

// 2 -----------------------------------
import UIKit

var view1 = UIView()
view1.alpha = 5

let view2 = UIView()
view2.alpha = 7 //  UIView is a class with reference semantics, so you can mutate the properties of view2

// view2 = view1 code will not compile
view1 = view2
print(view1.alpha)

// 3 ----------------------------------------
var animals = ["fish", "cat", "chicken", "dog"]
animals.sort(by: > ) // one liner sort
print(animals)

// 4 --------------------------------------
class Address {
  var fullAddress: String
  var city: String
  
  init(fullAddress: String, city: String) {
    self.fullAddress = fullAddress
    self.city = city
  }
}

class Person {
  var name: String
  var address: Address
  
  init(name: String, address: Address) {
    self.name = name
    self.address = address
  }
}

var headquarters = Address(fullAddress: "123 Tutorial Street", city: "Appletown")
var ray = Person(name: "Ray", address: headquarters)
var brian = Person(name: "Brian", address: headquarters)

brian.address.fullAddress = "104 street"
print(ray.address.fullAddress) // Address is a class and has reference semantics so headquarters is the same instance, whether you access it via ray or brian. Changing the address of headquarters will change it for both.

// 5 Beginner Verbal Questions ---------------------------------------------

// Swift extends the lack of value concept to both reference and value types(int, float) with optionals. An optional variable can hold either a value or nil, indicating a lack of value. This ability not available in Objective c
// Classes support inheritance; structures don't.
// Classes are reference types; structures are value types.
// In Swift, you can use generics in both functions and data types, e.g. in classes, structures or enumerations.Generics solve the problem of code duplication. When you have a method that takes one type of parameter, it's common to duplicate it to accommodate a parameter of a different type. By adopting generics, you can combine the two functions into one and keep type safety at the same time. Here's the generic implementation:
func areTheyEqual<T: Equatable>(_ x: T, _ y: T) -> Bool {
  return x == y
}

areTheyEqual("ray", "ray")
areTheyEqual(1, 1)
// To solve the strong reference cycle problem, which is when two instances refer to each other and require a non-nil reference to the other instance. In such a case, you mark one side of the reference as unowned, while the other uses an implicitly unwrapped optional.
//A typical example is an Interface Builder outlet, which always initializes after its owner. In this specific case — assuming it's properly configured in Interface Builder — you've guaranteed that the outlet is non-nil before you use it.
// There are seven ways to unwrap an optional
/*
Forced unwrapping — unsafe.

let a: String = x!

Implicitly unwrapped variable declaration — unsafe in many cases.

var a = x!

//Optional binding — safe.

if let a = x {
  print("x was successfully unwrapped and is = \(a)")
}

Optional chaining — safe.

let a = x?.count

Nil coalescing operator — safe.

let a = x ?? ""

Guard statement — safe.

 guard let a = x else {
   return
 }

Optional pattern — safe.

 if case let a? = x {
   print(a)
 }

*/

// There is no difference, as Optional.none (.none for short) and nil are equivalent.
nil == .none

// 6 ------------------------------------------
public class ThermometerClass {
  private(set) var temperature: Double = 0.0
  public func registerTemperature(_ temperature: Double) {
    self.temperature = temperature
  }
}

let thermometerClass = ThermometerClass()
thermometerClass.registerTemperature(56.0)

public struct ThermometerStruct {
  private(set) var temperature: Double = 0.0
  public mutating func registerTemperature(_ temperature: Double) {
    self.temperature = temperature
  }
}

var thermometerStruct = ThermometerStruct()
thermometerStruct.registerTemperature(56.0) // With structures, you must mark methods that change the internal state as mutating, but you cannot invoke them from immutable variables like let thermometerStruct = ThermometerStruct() .

// 7 ------------------------------------------------
var thing = "cars"

let closure = { [thing] in
  print("I love \(thing)")
}

thing = "airplanes"

closure()

// it'll print: I love cars. The capture list/array creates a copy of thing when you declare the closure. This means that captured value doesn't change even if you assign a new value to thing.

//If you omit the capture list in the closure, then the compiler uses a reference instead of a copy. Therefore, when you invoke the closure, it reflects any change to the variable. You can see this in the following code:
var thing1 = "cars"

let closure1 = {
  print("I love \(thing)")
}

thing1 = "airplanes"

closure1() // Prints: "I love airplanes"

// 8 -----------------------------------------------------
func countUniques<T: Comparable>(_ array: Array<T>) -> Int {
  let sorted = array.sorted()
  let initial: (T?, Int) = (.none, 0)
  let reduced = sorted.reduce(initial) {
    ($1, $0.0 == $1 ? $0.1 : $0.1 + 1)
  }
  return reduced.1
}
countUniques([1,3, 2, 3, 3,9,9,9,9])
extension Array where Element: Comparable {
  func countUniques() -> Int {
    let sortedValues = sorted()
    let initial: (Element?, Int) = (.none, 0)
    let reduced = sortedValues.reduce(initial) {
      ($1, $0.0 == $1 ? $0.1 : $0.1 + 1)
    }
    return reduced.1
  }
}
[1, 2, 3, 3].countUniques()
//Note that the new method is available only when the generic Element type conforms to Comparable.

// 9 ---------------------------------------------
func divide(_ dividend: Double?, by divisor: Double?) -> Double? {
  if dividend == nil {
    return nil
  }
  if divisor == nil {
    return nil
  }
  if divisor == 0 {
    return nil
  }
  return dividend! / divisor!
}
//  guard is very helpful when checking preconditions because it lets you express them in a clear way — without the pyramid of doom of nested if statements. Here is an example:
func divide1(_ dividend: Double?, by divisor: Double?) -> Double? {
   guard let dividend = dividend, let divisor = divisor, divisor != 0 else {
       return nil
     }
   return dividend / divisor
}
// another way with iflet
func divide2(_ dividend: Double?, by divisor: Double?) -> Double? {
   if let dividend = dividend, let divisor = divisor, divisor != 0 {
       return dividend / divisor
   } else {
     return nil
   }
}

// 10 ---------------------------------
// const int number = 0; obj c declation of constant // const is a variable initialized at compile time
// let number = 0 swift declation of constant // An immutable created with let is a constant determined at runtime. You can initialize it with a static or a dynamic expression.

// 11 ---------------------
// static makes a property or a function static and not overridable. Using class lets you override the property or function.
struct Sun {
  static func illuminate() {}
}

class Star {
  class func spin() {}
  static func illuminate() {}
}

class Sun1 : Star {
  override class func spin() {
    super.spin()
  }
  // error: class method overrides a 'final' class method
//  override static func illuminate() {
//    super.illuminate()
//  }
}
//12 ------------------------ Can you add a stored property to a type by using an extension? How or why not?
// No, it's not possible. You can use an extension to add new behavior to an existing type, but not to alter either the type itself or its interface. If you add a stored property, you'd need extra memory to store the new value. An extension cannot manage such a task.
struct FixedLengthRange {
    var firstValue: Int
    let length: Int
}
var rangeOfThreeItems = FixedLengthRange(firstValue: 0, length: 3)
// the range represents integer values 0, 1, and 2
rangeOfThreeItems.firstValue = 6
// the range now represents integer values 6, 7, and 8

//computed property
struct Point {
    var x = 0.0, y = 0.0
}
struct Size {
    var width = 0.0, height = 0.0
}
struct Rect {
    var origin = Point()
    var size = Size()
    var center: Point {
        get {
            let centerX = origin.x + (size.width / 2)
            let centerY = origin.y + (size.height / 2)
            return Point(x: centerX, y: centerY)
        }
        set(newCenter) {
            origin.x = newCenter.x - (size.width / 2)
            origin.y = newCenter.y - (size.height / 2)
        }
    }
}
var square = Rect(origin: Point(x: 0.0, y: 0.0),
                  size: Size(width: 10.0, height: 10.0))
let initialSquareCenter = square.center
square.center = Point(x: 15.0, y: 15.0)
print("square.origin is now at (\(square.origin.x), \(square.origin.y))")
// Prints "square.origin is now at (10.0, 10.0)"

// 13 ------------------ What is a protocol in Swift?
// A protocol is a type that defines a blueprint of methods, properties and other requirements. A class, structure or enumeration can then adopt the protocol to implement those requirements.

// 14 -----------------------
// Swift defines protocols that enable you to initialize a type with literal values by using the assignment operator.

// 15 ---------------
//Here, the operator is ^^ and the type is infix (binary). Associativity is right; in other words, equal precedence ^^ operators should evaluate the equation from right to left.
precedencegroup ExponentPrecedence {
  higherThan: MultiplicationPrecedence
  associativity: right
}
infix operator ^^: ExponentPrecedence
func ^^(base: Int, exponent: Int) -> Int {
  let l = Double(base)
  let r = Double(exponent)
  let p = pow(l, r)
  return Int(p)
}

// 16 -------------
struct Pizza {
  let ingredients: [String]
}

protocol Pizzeria {
  func makePizza(_ ingredients: [String]) -> Pizza
  func makeMargherita() -> Pizza // if line 302 commented then only lombardis2 would make the pizza with basil, whereas lombardis1 would make a pizza without it. because it would use the method defined in the extension.
}

extension Pizzeria {
  func makeMargherita() -> Pizza {
    return makePizza(["tomato", "mozzarella"])
  }
}
struct Lombardis: Pizzeria {
  func makePizza(_ ingredients: [String]) -> Pizza {
    return Pizza(ingredients: ingredients)
  }

  func makeMargherita() -> Pizza {
    return makePizza(["tomato", "basil", "mozzarella"])
  }
}

let lombardis1: Pizzeria = Lombardis()
let lombardis2: Lombardis = Lombardis()

lombardis1.makeMargherita()
lombardis2.makeMargherita()

// 17 ---------
//1st way
struct Kitten {
}

func showKitten(kitten: Kitten?) {
  guard let k = kitten else {
    print("There is no kitten")
    return
  }
  print(k)
}

// 2nd way
enum KittenError: Error {
  case NoKitten
}


func showKitten1(kitten: Kitten?) throws {
  guard let k = kitten else {
    print("There is no kitten")
    throw KittenError.NoKitten
  }
  print(k)
}

try showKitten1(kitten: nil)

// 3rd way
func showKitten2(kitten: Kitten?) {
  guard let k = kitten else {
    print("There is no kitten")
    fatalError()
  }
  print(k)
}

// 18 -------------------------------
//Closures are reference types. If you assign a closure to a variable and you copy the variable into another variable, you also copy a reference to the same closure and its capture list.
// A circular reference happens when two instances hold a strong reference to each other, causing a memory leak because neither of the two instances will ever be deallocated. The reason is that you cannot deallocate an instance as long as there's a strong reference to it, but each instance keeps the other alive because of its strong reference. You'd solve the problem by breaking the strong circular reference by replacing one of the strong references with a weak or an unowned reference.
// Swift allows the creation of recursive enumerations.
// It's the indirect keyword that allows for recursive enumeration cases like this:
enum List<T> {
  indirect case node(T, List<T>)
}

